INSERT INTO MOVIE (id, title, ageRating) VALUES (1, 'Saw', '18');
INSERT INTO MOVIE (id, title, ageRating) VALUES (2, 'Up', 'U');
INSERT INTO MOVIE (id, title, ageRating) VALUES (3, 'Hop', 'U');
INSERT INTO MOVIE (id, title, ageRating) VALUES (4, 'Some Film', 'PG');
